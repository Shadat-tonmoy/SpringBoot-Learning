package com.example.japAdvanced;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JapAdvancedApplicationTests {

	@Test
	void contextLoads() {
	}

}
