package com.example.springbootSecurityFull;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootSecurityFullApplicationTests {

	@Test
	void contextLoads() {
	}

}
