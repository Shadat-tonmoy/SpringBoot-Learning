package com.example.springbootSecurityFull;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootSecurityFullApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootSecurityFullApplication.class, args);
	}

}
